<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/18
 * Time: 20:52
 */

namespace app\api\controller\v1;


use think\Controller;

class User extends Controller
{
    public function test(){
        return "Hello this is test";
    }

}