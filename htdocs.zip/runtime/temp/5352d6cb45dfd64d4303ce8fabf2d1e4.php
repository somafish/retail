<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:64:"F:\xmal\htdocs\public/../application/index\view\index\index.html";i:1553153492;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    This is for test!

</body>
</html>