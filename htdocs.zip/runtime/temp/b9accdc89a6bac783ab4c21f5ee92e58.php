<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"F:\xmal\htdocs\public/../application/api\view\v1\banner\index.html";i:1553044811;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
This is test
</body>
</html>